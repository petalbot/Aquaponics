# Aquaponics
Feeding Fish
Aquaponics Game: Java game where user aims to feed fish of three different colors without exceeding virtual ammonia limit
This game generates fish of three different color schemes and random swimming speeds. 
Each comes with an attached bar indiciating how much more they must be fed to win the game. 
Clicking the food can will change the food can's color to match one of the three fish color schemes. 
Pressing the keys named in the prompt rotates the can to be aimed at fish. 
Feeding a fish of the same color as the can will contribute to its bar. 
Feeding a fish of the wrong color will cause virtual ammonia levels to rise. 
Succeesfully completing the feed will cause the backgroud plants to grow. 
